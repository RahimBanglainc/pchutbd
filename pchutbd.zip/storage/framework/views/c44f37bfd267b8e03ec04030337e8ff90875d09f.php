<?php $__env->startSection('title','Deshboard'); ?>


<?php $__env->startSection('main'); ?>

<div id="app">

    <div name="clientForm" action="" method="post">


        <input type="hidden" name="UserID" value="23272">

        <div class="container">

            <div class="row">


                <?php echo $__env->make('storefront.components.saidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                <div class="ten columns account-head">



                    <div class="body-header">
                        <h1>Favourite</h1>
                    </div>

<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="row product-cat-box s-top">

    <div class="six columns product-cat-box-img">
        <div class="row">
            <div class="seven columns">
                <a href="<?php echo e(route('item.view', $item->slug)); ?>" target="_BLANK">
                    <img src="<?php echo e(asset('/s'.$item->img)); ?>"
                        alt="<?php echo e($item->title); ?>"
                        title="<?php echo e($item->title); ?>">
                </a> </div>
            <div class="five columns">
                <div class="product-price-group">
                    <div class="product-price">৳ <?php echo e($item->price); ?></div>
                    <div class="product-update-date"><?php echo e($item->updated_at->diffForHumans()); ?></div>

                    <div class="product-cat-box-button">
                    <a href="javascript:void(0)" onclick="document.getElementById('favorite-form-<?php echo e($item->id); ?>').submit()">
                            <div class="button-link">Remove</div>
                        </a>
                        <form id="favorite-form-<?php echo e($item->id); ?>" method="POST" action="<?php echo e(route('favorite.post', $item->id)); ?>" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>


    <div class="six columns product-cat-box-text">
        <a href="<?php echo e(route('item.view', $item->slug)); ?>" target="_BLANK"><?php echo e($item->title); ?></a>
        <p><?php echo \Illuminate\Support\str::limit(strip_tags($item->description), 100); ?> </p>
    </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <br class="clear">
                </div>


            </div>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/storefront/favourite.blade.php ENDPATH**/ ?>