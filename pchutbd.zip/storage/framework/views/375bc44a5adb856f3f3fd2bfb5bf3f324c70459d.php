<?php $__env->startSection('title','Stalls List'); ?>



<?php $__env->startSection('main'); ?>

<?php $__env->startPush('css'); ?>

 <!-- Sweet Alert-->
 <link href="<?php echo e(asset('admin/assets/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />

<!-- jquery.vectormap css -->
<link
href="<?php echo e(asset('admin/assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css')); ?>"
rel="stylesheet" type="text/css" />

<!-- DataTables -->
<link
href="<?php echo e(asset('admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>"
rel="stylesheet" type="text/css" />

<!-- Responsive datatable examples -->
<link
href="<?php echo e(asset('admin/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>"
rel="stylesheet" type="text/css" />


<?php $__env->stopPush(); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0">Dashboard</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">PCHUTBD</a></li>
                    <li class="breadcrumb-item active">Store</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="dropdown float-right">
                    
                </div>

                <h4 class="card-title mb-4">All Stalls</h4>

                <div class="table-responsive">
                    <table class="table table-centered datatable dt-responsive nowrap" data-page-length="10"
                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead class="thead-light">
                            <tr>
                                <th style="width: 20px;">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="ordercheck">
                                        <label class="custom-control-label" for="ordercheck">&nbsp;</label>
                                    </div>
                                </th>
                                <th>ID</th>
                                <th>Store Name</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>Phone</th>
                                <th>Type</th>
                                <th>Auth Status</th>
                                <th>Status</th>
                                <th>Request On</th>
                                <th style="width: 120px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $stalls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$stall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="ordercheck1">
                                        <label class="custom-control-label" for="ordercheck1">&nbsp;</label>
                                    </div>
                                </td>

                                <td><a href="javascript: void(0);" class="text-dark font-weight-bold"><?php echo e($key + 1); ?></a> </td>
                                <td>
                                <a href="<?php echo e(route('admin.stall.show', $stall->id)); ?>">
                                        <?php echo e(\Illuminate\Support\Str::limit($stall->name, 30)); ?>

                                        
                                    </a>
                                </td>
                                <td>
                                    <?php echo \Illuminate\Support\str::limit(strip_tags($stall->address), 50); ?>

                                    
                                </td>
                                <td>
                                    <?php echo e($stall->city); ?>

                                </td>
                                <td>
                                    <?php echo \Illuminate\Support\str::limit(strip_tags($stall->phone), 50); ?>

                                    
                                </td>
                                <td>
                                    <div class="badge badge-soft-warning font-size-12"> <?php echo $stall->type; ?></div>
                                    
                                </td>

                                <td>
                                    <?php if($stall->user()->find($stall->user_id)->is_seller == true): ?>
                                    <div class="badge badge-soft-success font-size-12">Approve</div>

                                    <?php else: ?>
                                    <div class="badge badge-soft-danger font-size-12">Not Approve</div>

                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if($stall->status == true): ?>
                                    <div class="badge badge-soft-success font-size-12">Active</div>

                                    <?php else: ?>
                                    <div class="badge badge-soft-danger font-size-12">Disable</div>

                                    <?php endif; ?>
                                </td>
                                <td>

                                    <div class="badge badge-soft-info font-size-12"><?php echo e($stall->created_at->diffForHumans()); ?></div>

                                </td>

                                <td>
                                    <a href="<?php echo e(route('admin.stall.edit', $stall->id)); ?>" class="mr-3 text-primary" data-toggle="tooltip"
                                        data-placement="top" title="" data-original-title="Edit"><i
                                            class="mdi mdi-pencil font-size-18"></i></a>

                                    <a href="<?php echo e(route('admin.stall.show', $stall->id)); ?>" class="text-danger" data-toggle="tooltip"
                                        data-placement="top" title="" data-original-title="View">
                                        <i class="mdi mdi-eye font-size-18"></i>
                                    </a>

                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('js'); ?>

<!-- apexcharts -->
<script src="<?php echo e(asset('admin/assets/libs/apexcharts/apexcharts.min.js')); ?>">
</script>

<!-- jquery.vectormap map -->
<script
    src="<?php echo e(asset('admin/assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js')); ?>">
</script>
<script
    src="<?php echo e(asset('admin/assets/libs/admin-resources/jquery.vectormap/maps/jquery-jvectormap-us-merc-en.js')); ?>">
</script>

<!-- Required datatable js -->
<script
    src="<?php echo e(asset('admin/assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>">
</script>
<script
    src="<?php echo e(asset('admin/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>">
</script>

<!-- Responsive examples -->
<script
    src="<?php echo e(asset('admin/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>">
</script>
<script
    src="<?php echo e(asset('admin/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>">
</script>

<script src="<?php echo e(asset('admin/assets/js/pages/dashboard.init.js')); ?>"></script>


    <!-- Sweet Alerts js -->
    <script src="<?php echo e(asset('admin/assets/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>

    <!-- Sweet alert init js-->
    <script src="<?php echo e(asset('admin/assets/js/pages/sweet-alerts.init.js')); ?>"></script>

<?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/admin/stall/index.blade.php ENDPATH**/ ?>