<?php $__env->startSection('title','Edit SubCategory'); ?>

<?php $__env->startPush('css'); ?>

    <!-- Summernote css -->
    <link href="<?php echo e(asset('admin/assets/libs/summernote/summernote-bs4.min.cs')); ?>s"
        rel="stylesheet" type="text/css" />

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0">Dashboard</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">PCHUTBD</a></li>
                    <li class="breadcrumb-item active">Edit Sub Category</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<form method="POST" action="<?php echo e(route('admin.subcategory.update', $category->id)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body" style="height:490px;">
                    <h4 class="card-title">Edit SubCategory</h4>
                    <div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Category</label>
                            <div class="col-md-9">
                                <select name="Category_id" class="form-control">
                                <option value="<?php echo e($category->Category_id); ?>"><?php echo e(App\Category::where('id',$category->Category_id)->first()->name); ?></option>
                                    <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="name" placeholder="Category Name" value="<?php echo e($category->name); ?>" required>
                        </div>
                        <h4 class="card-title">Picture Upload</h4>
                        <p class="card-title-desc"> Upload 100x100 px</p>
                        <div class="col-md-6">
                        <img class="img-thumbnail" alt="200x200" style="height:100px;" src="<?php echo e(asset('/'.$category->img)); ?>" data-holder-rendered="true">
                        </div>
                        <br>
                        <div class="custom-file">
                            <input type="file" name="img" class="custom-file-input" id="customFile">
                            <label class="custom-file-label" for="customFile">Choose Image</label>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card">
                
                <div class="card-body">

                    <a href="<?php echo e(route('admin.category.index')); ?>" class="btn btn-danger waves-effect waves-light">
                        Back
                    </a>
                    <button type="submit" class="btn btn-primary waves-effect waves-light">
                        Update <i class="ri-arrow-right-line align-middle ml-2"></i>
                    </button>

                </div>
            </div>
        </div>
    </div>
</form>



<!-- end main content-->
<?php $__env->startPush('js'); ?>

    <!-- Summernote js -->
    <script src="<?php echo e(asset('admin/assets/libs/summernote/summernote-bs4.min.js')); ?>"></script>

    <!-- bs custom file input plugin -->
    <script
        src="<?php echo e(asset('admin/assets/libs/bs-custom-file-input/bs-custom-file-input.min.js')); ?>">
    </script>

    <script src="<?php echo e(asset('admin/assets/js/pages/form-element.init.js')); ?>"></script>
    <!--tinymce js-->
    <script src="<?php echo e(asset('admin/assets/libs/tinymce/tinymce.min.js')); ?>"></script>

    <!-- init js -->
    <script src="<?php echo e(asset('admin/assets/js/pages/form-editor.init.js')); ?>"></script>

    </script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/admin/subcategory/edit.blade.php ENDPATH**/ ?>