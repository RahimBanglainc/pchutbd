<table width="100%" cellpadding="0" cellspacing="1" style="border:1px solid;">
    <tbody>
        <tr>
            <td width="100%" align="left" class="profileDetail" colspan="2"><b>Item Features</b> (Please fill up all
                these features)</td>
        </tr>

        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr style="background-color:#EFF0F2;">
                <td width="50%" align="left" class="profileDetail"><input type="hidden" name="feature_id[<?php echo e($key); ?>]"
                        value="<?php echo e($feature->id); ?>"><?php echo e($feature->name); ?></td>
                <td width="40%" align="left" class="profileDetail"><input type="text" name="value[<?php echo e($key); ?>]" value=""
                        size="20" maxlength="400"></td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td width="50%" align="left" class="profileDetail"><input type="hidden" name="" value="170">Warranty</td>
            <td width="40%" align="left" class="profileDetail"><input type="text" name="warranty" value="" size="20"
                    maxlength="400"></td>
        </tr>
    </tbody>
</table><input type="hidden" name="rowCount" value="<?php echo e($features->count()); ?>">
<?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/storefront/components/feature.blade.php ENDPATH**/ ?>