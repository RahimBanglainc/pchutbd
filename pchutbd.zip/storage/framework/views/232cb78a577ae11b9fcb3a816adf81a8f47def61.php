<div class="two columns account-panel">

    <div class="body-header">
        <h1>Control Panel</h1>
    </div>

    <?php if(Auth::User()->is_seller): ?>
        <div>
            <div>
                <a href="<?php echo e(route('client.item.index')); ?>">
                    Manage Item
                </a>
            </div>
            <div>
                <a href="<?php echo e(route('client.item.create')); ?>">
                    Post New Item
                </a>
            </div>
            <div>
                <a href="<?php echo e(route('client.editstall')); ?>">
                    Edit Stall
                </a>
            </div>
        </div>

        <div>
            <a href="<?php echo e(route('client.order')); ?>">Orders</a>
        </div>

        <div><a href="<?php echo e(route('client.invoice')); ?>">Invoice</a></div>

        <div><a href="<?php echo e(route('client.payment')); ?>">Payment</a></div>

    <?php else: ?>

    <div>
        <a href="<?php echo e(route('client.myorder')); ?>">My Order</a>
    </div>

    <div>
        <a href="<?php echo e(route('client.stallreq')); ?>">
            Stall Request
        </a>
    </div>

    <?php endif; ?>

    <div>
        <a href="<?php echo e(route('client.favourite')); ?>">Favourite&nbsp;(<?php echo e(Auth::user()->favorite_items()->count()); ?>)</a>
    </div>

    <div><a href="<?php echo e(route('client.profile')); ?>">Update Profile</a>
    </div>

    <div>
        <a href="<?php echo e(route('client.Passwordshow')); ?>">Change Password</a>
    </div>




    <div>
        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
            <?php echo e(__('Sing Out')); ?>

        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>


</div>
<?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/storefront/components/saidbar.blade.php ENDPATH**/ ?>