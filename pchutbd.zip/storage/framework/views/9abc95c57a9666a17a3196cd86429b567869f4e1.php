<?php $__env->startSection('title','Edit Item'); ?>

<?php $__env->startPush('css'); ?>

    <!-- Summernote css -->
    <link href="<?php echo e(asset('admin/assets/libs/summernote/summernote-bs4.min.cs')); ?>s"
        rel="stylesheet" type="text/css" />

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0">Dashboard</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">PCHUTBD</a></li>
                    <li class="breadcrumb-item active">Edit Item</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<form method="POST" action="<?php echo e(route('admin.item.update', $item->id)); ?>"
    enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body" style="">
                    <h4 class="card-title">Item Update</h4>
                    <p class="card-title-desc"></code>All Information Input From Stall User</p>
                    <div>
                        <div class="mb-4">
                            <label>Item Title</label>
                            <input class="form-control" type="text" name="title" placeholder="Blog Title"
                                value="<?php echo e($item->title); ?>" required>
                        </div>
                        <div class="mb-4">
                            <label>Model</label>
                            <input class="form-control" type="text" name="model" placeholder="item Title"
                                value="<?php echo e($item->model); ?>" required>
                        </div>
                        <div class="mb-4">
                            <label>Item Price</label>
                            <input class="form-control" type="text" name="price" placeholder="item Title"
                                value="<?php echo e($item->price); ?>" required>
                        </div>
                        <div class="mb-4">
                            <label>Shipping in Dhaka</label>
                            <input class="form-control" type="text" name="ship_dhaka" placeholder="item Title"
                                value="<?php echo e($item->ship_dhaka); ?>">
                        </div>
                        <div class="mb-4">
                            <label>Shipping All Bangladesh</label>
                            <input class="form-control" type="text" name="ship_bd" placeholder="item Title"
                                value="<?php echo e($item->ship_bd); ?>">
                        </div>
                        <div class="mb-4">
                            <label>Offer</label>
                            <textarea name="offer" placeholder="Offer" class="form-control"
                                rows="5"><?php echo e($item->offer); ?></textarea>
                        </div>
                        <div class="mb-4">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="5"
                                required><?php echo e($item->description); ?></textarea>
                        </div>
                        <label>Stall</label>
                        <div class="col-md-12 mb-4">
                            <select class="form-control">
                                <option>Select</option>
                                <option value="<?php echo e($item->stall_id); ?>" selected=""><?php echo e($item->stall()->where('id', $item->stall_id)->first()->name); ?></option>

                            </select>
                        </div>
                        <label>SubCategory</label>
                        <div class="col-md-12 mb-4">
                            <select class="form-control">
                                <option>Select</option>
                                <option value="<?php echo e($item->subcategory_id); ?>" selected=""><?php echo e($item->subcategory()->where('id', $item->subcategory_id)->first()->name); ?></option>
                            </select>
                        </div>
                        <label>Brand</label>
                        <div class="col-md-12 mb-4">
                            <select class="form-control">
                                <option>Select</option>
                                <option value="0" selected="">Others</option>
                            </select>
                        </div>
                        <label>Stock</label>
                        <div class="col-md-12 mb-4">
                            <select name="stock" class="form-control">
                                <option>Select</option>
                                <option value="1"
                                    <?php echo e($item->stock ? 'selected':''); ?>>
                                    In Stock</option>
                                <option value="0"
                                    <?php echo e($item->stock ? '':'selected'); ?>>
                                    Sold Out</option>
                            </select>
                        </div>



                        <h4 class="card-title">Picture Upload</h4>
                        <p class="card-title-desc"> Upload 350x350px</p>
                        <div class="row">
                            <div class="col-md-2">

                            </div>
                            <div class="col-md-2">
                                <?php if(Storage::disk('public')->exists('item/'.$item->img)): ?>


                                <img class="img-thumbnail" alt="200x200" style="width:100px;"
                                    src="<?php echo e(asset('/'.$item->img)); ?>"
                                    data-holder-rendered="true">

                                <?php else: ?>

                                <img class="img-thumbnail" alt="200x200" style="width:100px;" src="<?php echo e(asset('img/picture.jpg')); ?>" data-holder-rendered="true">

                                <?php endif; ?>
                            </div>
                            <div class="col-md-2">
                                <?php if(Storage::disk('public')->exists('item/'.$item->img1)): ?>


                                <img class="img-thumbnail" alt="200x200" style="width:100px;"
                                    src="<?php echo e(asset('/'.$item->img1)); ?>"
                                    data-holder-rendered="true">

                                <?php else: ?>

                                <img class="img-thumbnail" alt="200x200" style="width:100px;" src="<?php echo e(asset('img/picture.jpg')); ?>" data-holder-rendered="true">

                                <?php endif; ?>
                            </div>
                            <div class="col-md-2">
                                <?php if(Storage::disk('public')->exists('item/'.$item->img2)): ?>


                                <img class="img-thumbnail" alt="200x200" style="width:100px;"
                                    src="<?php echo e(asset('/'.$item->img2)); ?>"
                                    data-holder-rendered="true">

                                <?php else: ?>

                                <img class="img-thumbnail" alt="200x200" style="width:100px;" src="<?php echo e(asset('img/picture.jpg')); ?>" data-holder-rendered="true">

                                <?php endif; ?>
                            </div>
                            <div class="col-md-2">
                                <?php if(Storage::disk('public')->exists('item/'.$item->img3)): ?>


                                <img class="img-thumbnail" alt="200x200" style="width:100px;"
                                    src="<?php echo e(asset('/'.$item->img3)); ?>"
                                    data-holder-rendered="true">

                                <?php else: ?>

                                <img class="img-thumbnail" alt="200x200" style="width:100px;" src="<?php echo e(asset('img/picture.jpg')); ?>" data-holder-rendered="true">

                                <?php endif; ?>
                            </div>
                            <div class="col-md-2">
                                <?php if(Storage::disk('public')->exists('item/'.$item->img4)): ?>


                                <img class="img-thumbnail" alt="200x200" style="width:100px;"
                                    src="<?php echo e(asset('/'.$item->img4)); ?>"
                                    data-holder-rendered="true">

                                <?php else: ?>

                                <img class="img-thumbnail" alt="200x200" style="width:100px;" src="<?php echo e(asset('img/picture.jpg')); ?>" data-holder-rendered="true">

                                <?php endif; ?>
                            </div>


                        </div>
                        <br>
                        <div class="custom-file">
                            <input type="file" name="img" class="custom-file-input" id="customFile">
                            <label class="custom-file-label" for="customFile">Choose Image</label>
                        </div>
                        <br><br>
                        <div class="custom-file">
                            <input type="file" name="img1" class="custom-file-input" id="customFile">
                            <label class="custom-file-label" for="customFile">Choose Image 1</label>
                        </div>
                        <br><br>
                        <div class="custom-file">
                            <input type="file" name="img2" class="custom-file-input" id="customFile">
                            <label class="custom-file-label" for="customFile">Choose Image 2</label>
                        </div>
                        <br><br>
                        <div class="custom-file">
                            <input type="file" name="img3" class="custom-file-input" id="customFile">
                            <label class="custom-file-label" for="customFile">Choose Image 3</label>
                        </div>
                        <br><br>
                        <div class="custom-file">
                            <input type="file" name="img4" class="custom-file-input" id="customFile">
                            <label class="custom-file-label" for="customFile">Choose Image 4</label>
                        </div>
                        <br><br>


                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">Item Features</h4>
                    <p class="card-title-desc">Not Change Features</p>


                    <table style="width:100%">
                        <tbody>


                            <?php $__currentLoopData = App\FeatureValue::where('item_id', $item->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td width="30%" align="center">
                                        <input type="hidden" name="feature_id[<?php echo e($key); ?>]" value="<?php echo e($value->feature_id); ?>">
                                        <?php echo e($value->feature()->where('id', $value->feature_id)->first()->name); ?>

                                    </td>
                                    <td width="70%" align="left">
                                        <input type="text" readonly="readonly" name="value[<?php echo e($key); ?>]"
                                            value=" <?php echo e($value->value); ?>" style="width:100% !important">
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            <tr>
                                <td width="30%" align="center">

                                    Warranty </td>
                                <td width="70%" align="left">
                                    <input type="text" name="warranty"
                                        value="<?php echo e($item->warranty); ?>" style="width:100% !important">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <input type="hidden" name="rowCount" value="<?php echo e(App\FeatureValue::where('item_id', $item->id)->count()); ?>">





                    <br>

                    <?php if(!$item->is_approve == 1): ?>

                    <div class="custom-control custom-switch mb-2" dir="ltr">
                        <input type="checkbox" name="is_approve" class="custom-control-input" id="customSwitch1"
                            value="true"
                            <?php echo e($item->is_approve == true ?'checked' : ''); ?>>
                        <label class="custom-control-label" for="customSwitch1">Approve Item</label>
                    </div>

                    <?php else: ?>

                    <div class="custom-control custom-switch mb-2" dir="ltr">
                        <input type="checkbox" name="status" class="custom-control-input" id="customSwitch2" value="1"
                            <?php echo e($item->status == true ?'checked' : ''); ?>>
                        <label class="custom-control-label" for="customSwitch2">Active/Disable Item</label>
                    </div>

                    <?php endif; ?>


                </div>
                <div class="card-body">

                    <a href="<?php echo e(route('admin.item.index')); ?>"
                        class="btn btn-danger waves-effect waves-light">
                        Back
                    </a>
                    <button type="submit" class="btn btn-primary waves-effect waves-light">
                        Update <i class="ri-arrow-right-line align-middle ml-2"></i>
                    </button>

                </div>
            </div>
        </div>
    </div>
</form>



<!-- end main content-->
<?php $__env->startPush('js'); ?>

    <!-- Summernote js -->
    <script src="<?php echo e(asset('admin/assets/libs/summernote/summernote-bs4.min.js')); ?>"></script>

    <!-- bs custom file input plugin -->
    <script
        src="<?php echo e(asset('admin/assets/libs/bs-custom-file-input/bs-custom-file-input.min.js')); ?>">
    </script>

    <script src="<?php echo e(asset('admin/assets/js/pages/form-element.init.js')); ?>"></script>
    <!--tinymce js-->
    <script src="<?php echo e(asset('admin/assets/libs/tinymce/tinymce.min.js')); ?>"></script>

    <!-- init js -->
    <script src="<?php echo e(asset('admin/assets/js/pages/form-editor.init.js')); ?>"></script>

    </script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/admin/item/edit.blade.php ENDPATH**/ ?>