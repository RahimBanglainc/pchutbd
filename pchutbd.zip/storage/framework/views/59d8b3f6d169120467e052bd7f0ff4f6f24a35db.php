<?php $__env->startSection('title', $page->name); ?>



<?php $__env->startSection('main'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<div class="container b-top">


    <div class="body-header">

        <h1><?php echo e($page->name); ?></h1>
    </div>
</div>



<div class="container">


    <?php echo $page->body; ?>




</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/page.blade.php ENDPATH**/ ?>