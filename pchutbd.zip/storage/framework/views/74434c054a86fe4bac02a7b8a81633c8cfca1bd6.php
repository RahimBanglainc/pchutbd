<?php $__env->startSection('title','Deshboard'); ?>


<?php $__env->startSection('main'); ?>

<div id="app">

    <div name="clientForm" action="" method="post">


        <input type="hidden" name="UserID" value="23272">

        <div class="container">

            <div class="row">


                <?php echo $__env->make('storefront.components.saidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                <div class="ten columns account-head">



                    <div class="body-header">
                        <h1>Payment List</h1>
                    </div>

                    <div class="adm-search-panel">

                        <div class="u-pull-right product-cat-stat">Balance ৳ 0.00</div>

                    </div>


                    <div clas="row">

                        <div class="tweleve columns">





                        </div>



                    </div>


                    <br class="clear">
                </div>





            </div>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/storefront/payment.blade.php ENDPATH**/ ?>