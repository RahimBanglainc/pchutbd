<?php $__env->startSection('title','Blog'); ?>

<?php $__env->startSection('main'); ?>

<?php $__env->startPush('css'); ?>

<style>
    /* The alert message box */
.alert {
  padding: 20px;
  background-color: #ff9800; /* Red */
  color: white;
  margin-bottom: 15px;
  border-radius: 10px;
}

/* The close button */
.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

/* When moving the mouse over the close button */
.closebtn:hover {
  color: black;
}
</style>


<?php $__env->stopPush(); ?>


<div class="container">

    <form name="clientForm" method="post" enctype="multipart/form-data">

        <div class="m-top breadcum">
            <label>

                <a href="<?php echo e(route('index')); ?>" class="sortLink">Home</a><span>
                    &nbsp;&gt;&nbsp;</span><a class="sortLinkClk" href="<?php echo e(route('blog')); ?>">Blog</a>

            </label>


        </div>


        <div class="row">

            <?php if($blog->status == true): ?>

            <div class="mag-body-header">
                <h1><?php echo e($blog->title); ?></h1>
            </div>

            <div class="row s-top">
                <div class="u-pull-left"><?php echo e($blog->created_at->toFormattedDateString()); ?></div>
                <div class="u-pull-right">
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('blog.show',$blog->slug)); ?>"
                        target="_blank">
                        <img alt="Share on Facebook" title="Share on Facebook"
                            src="<?php echo e(asset('img/fb_share.jpg')); ?>">
                    </a>
                    <a target="_blank"
                        href="http://twitter.com/home?status=<?php echo e(route('blog.show',$blog->slug)); ?>"><img
                            alt="Post on Twitter" title="Post on Twitter"
                            src="<?php echo e(asset('img/twitter_share.jpg')); ?>"></a>
                </div>
            </div>

            <div class="mag-content">

                <?php echo $blog->body; ?>


                <hr>
            </div>


            <?php else: ?>

                <div class="alert alert-info">
                    <strong>Info!</strong> This Blog is Inactive from Admin.
                </div>

              

            <?php endif; ?>

            <div class="product-review b-top">


                <input type="hidden" name="id" value="434">
                <input type="hidden" name="url_title" value="tips-for-using-hair-trimmer">
                <input type="hidden" name="lang_id" value="2">
                

            </div>
            <br>


            <div class="row u-full-width u-pull-left m-top">

                <?php $__currentLoopData = $rblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($rblog->status == true): ?>

                    <div class="mag-related-box" style="max-height: 10em">

                        <a href="<?php echo e(route('blog.show',$rblog->slug)); ?>">
                            <div class="mag-related-box-img">
                                <img src="<?php echo e(Storage::disk('public')->url('blog/'.$rblog->img)); ?>"
                                    title="<?php echo e($blog->title); ?>">
                            </div>
                            <div class="mag-related-box-item-title">
                                <?php echo e(\Illuminate\Support\str::limit($rblog->title, 27)); ?>

                            </div>
                        </a>
                    </div>

                <?php endif; ?>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    </form>



</div>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/blog/show.blade.php ENDPATH**/ ?>