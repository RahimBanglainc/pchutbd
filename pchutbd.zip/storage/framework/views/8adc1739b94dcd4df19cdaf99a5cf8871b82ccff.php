<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>

    <meta charset="utf-8" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'PCHUTBD')); ?></title>


    <!-- Fonts -->
    


    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesdesign" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('admin/assets/images/favicon.ico')); ?>">

    
    



    <?php echo $__env->yieldPushContent('css'); ?>


    <!-- Bootstrap Css -->
    
    <link href="<?php echo e(asset('admin/assets/css/bootstrap-dark.min.css')); ?>"
 rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('admin/assets/css/icons.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <!-- App Css-->
    
    <link href="<?php echo e(asset('admin/assets/css/app-dark.min.css')); ?>"
     rel="stylesheet" type="text/css" />


</head>

<body data-sidebar="dark">
    <!-- Begin page -->
    <div id="layout-wrapper">



            <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('layouts.admin.saidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <div id="app">

                            <?php echo $__env->yieldContent('main'); ?>

                        </div>


                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->







            <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            <!-- JAVASCRIPT -->
            <script src="<?php echo e(asset('admin/assets/libs/jquery/jquery.min.js')); ?>"></script>
            <script
            src="<?php echo e(asset('admin/assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>">
            </script>
            <script src="<?php echo e(asset('admin/assets/libs/metismenu/metisMenu.min.js')); ?>">
            </script>
            <script src="<?php echo e(asset('admin/assets/libs/simplebar/simplebar.min.js')); ?>">
            </script>
            <script src="<?php echo e(asset('admin/assets/libs/node-waves/waves.min.js')); ?>"></script>
            
             <!-- toastr plugin -->
            

            <?php echo $__env->yieldPushContent('js'); ?>

            <script src="<?php echo e(asset('admin/assets/js/app.js')); ?>"></script>

            <!-- vue Scripts -->
            <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/layouts/admin/layout.blade.php ENDPATH**/ ?>