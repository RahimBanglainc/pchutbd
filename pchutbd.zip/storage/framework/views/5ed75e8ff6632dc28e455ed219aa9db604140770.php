

<div class="main-header">
    <div class="container">

        <a href="<?php echo e(route('index')); ?>">


            <img src="<?php echo e(asset('/'.App\Settings::find(1)->head_img)); ?>" alt="pchutbd.com" title="pchutbd.com">

        </a>

        <div class="spinner-master">
            <input type="checkbox" id="spinner-form">
            <label for="spinner-form" class="spinner-spin">
                <div class="spinner diagonal part-1"></div>
                <div class="spinner horizontal"></div>
                <div class="spinner diagonal part-2"></div>
            </label>

        </div>

        <input type="hidden" name="DepartmentID" value="-1">
        <input type="hidden" name="ItemTypeID" value="-1">
        <a href="##search_box" class="search-btn" id="search"><img
                src="<?php echo e(asset('img/site-search-icon.png')); ?>">
        </a>

        <form class="search_box" id="search_box" method="GET" action="<?php echo e(route('search')); ?>">
            <input name="query" placeholder="Search item" value="" type="text">
            <input class="search_icon" value="Search" type="submit">
        </form>


        <div class="main-header-link">

            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('register')): ?>
                    <div class="main-header-desk-link">
                        <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                    </div>
                <?php endif; ?>

                <a href="<?php echo e(route('login')); ?>">
                    <div class="main-header-login-link"><?php echo e(__('Login')); ?></div>
                </a>

            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">
                    <div class="main-header-login-link">Home</div>
                </a>
            <?php endif; ?>


            <div class="main-header-desk-link"><a href="<?php echo e(route('blog')); ?>">Blog</a></div>
        </div>



    </div>


</div>


<nav id="menu" class="menu top-menu">
    <ul class="menu-pd">

        <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li class="has-submenu"><a href="<?php echo e(route('cat.view', $cat->slug)); ?>"><?php echo e($cat->name); ?>

                </a>


                <ul class="sub-menu">
                    <?php $__currentLoopData = App\Subcategory::where('Category_id', $cat->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li>
                            <a href="<?php echo e(route('catitem.view', $subcat->slug)); ?>"><?php echo e($subcat->name); ?></a>
                        </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </ul>
</nav>

<?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/layouts/storefront/header.blade.php ENDPATH**/ ?>