<?php $__env->startSection('title','Edit Stall'); ?>

<?php $__env->startPush('css'); ?>

    <!-- Summernote css -->
    

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0">Dashboard</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">PCHUTBD</a></li>
                    <li class="breadcrumb-item active">Edit Stall</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<form method="POST" action="<?php echo e(route('admin.stall.update', $stall->id)); ?>"
    enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Store Information Update Panel</h4>
                    <p class="card-title-desc">Store Owner:
                        <?php echo e($stall->user()->find($stall->user_id)->first()->name); ?></code>.</p>
                    <div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="name" placeholder="Store Name"
                                value="<?php echo e($stall->name); ?>" required>
                        </div>
                        <div class="mb-4">
                            <textarea id="textarea" name="address" class="form-control" maxlength="225" rows="3"
                                placeholder="Store Address" required><?php echo e($stall->address); ?></textarea>
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="area" placeholder="Store Area"
                                value="<?php echo e($stall->area); ?>" required>
                        </div>

                        <div class="form-group" data-select2-id="10">
                            <label class="control-label">Select City</label>
                            <select class="form-control select2 select2-hidden-accessible" name="city" required>
                                <option value="<?php echo e($stall->city ? $stall->city:''); ?>"
                                    selected>
                                    <?php echo e($stall->city ? $stall->city:'Select'); ?>

                                </option>
                                <option value="Bagherhat">Bagherhat</option>
                                <option value="Bandarban">Bandarban</option>
                                <option value="Barguna">Barguna</option>
                                <option value="Barisal">Barisal</option>
                                <option value="Bhola">Bhola</option>
                                <option value="Bogra">Bogra</option>
                                <option value="Brahmanbaria">Brahmanbaria</option>
                                <option value="Chandpur">Chandpur</option>
                                <option value="Chapainawabganj">Chapainawabganj</option>
                                <option value="Chittagong">Chittagong</option>
                                <option value="Chuadanga">Chuadanga</option>
                                <option value="Comilla">Comilla</option>
                                <option value="Cox's Bazar">Cox's Bazar</option>
                                <option value="Dhaka">Dhaka</option>
                                <option value="Dinajpur">Dinajpur</option>
                                <option value="Faridpur">Faridpur</option>
                                <option value="Feni">Feni</option>
                                <option value="Gaibandha">Gaibandha</option>
                                <option value="Gazipur">Gazipur</option>
                                <option value="Gopalganj">Gopalganj</option>
                                <option value="Habiganj">Habiganj</option>
                                <option value="Jamalpur">Jamalpur</option>
                                <option value="Jessore">Jessore</option>
                                <option value="Jhalokati">Jhalokati</option>
                                <option value="Jhenaidaha">Jhenaidaha</option>
                                <option value="Joypurhat">Joypurhat</option>
                                <option value="Khagrachhari">Khagrachhari</option>
                                <option value="Khulna">Khulna</option>
                                <option value="Kishoreganj">Kishoreganj</option>
                                <option value="Kurigram">Kurigram</option>
                                <option value="Kushtia">Kushtia</option>
                                <option value="Lakshmipur">Lakshmipur</option>
                                <option value="Lalmonirhat">Lalmonirhat</option>
                                <option value="Madaripur">Madaripur</option>
                                <option value="Magura">Magura</option>
                                <option value="Manikganj">Manikganj</option>
                                <option value="Maulvi Bazar">Maulvi Bazar</option>
                                <option value="Meherpur">Meherpur</option>
                                <option value="Munshiganj">Munshiganj</option>
                                <option value="Mymensingh">Mymensingh</option>
                                <option value="Naogaon">Naogaon</option>
                                <option value="Narail">Narail</option>
                                <option value="Narayanganj">Narayanganj</option>
                                <option value="Narsingdi">Narsingdi</option>
                                <option value="Natore">Natore</option>
                                <option value="Netrokona">Netrokona</option>
                                <option value="Nilphamari">Nilphamari</option>
                                <option value="Noakhali">Noakhali</option>
                                <option value="Pabna">Pabna</option>
                                <option value="Panchagarh">Panchagarh</option>
                                <option value="Patuakhali">Patuakhali</option>
                                <option value="Pirojpur">Pirojpur</option>
                                <option value="Rajbari">Rajbari</option>
                                <option value="Rajshahi">Rajshahi</option>
                                <option value="Rangamati">Rangamati</option>
                                <option value="Rangpur">Rangpur</option>
                                <option value="Saidpur">Saidpur</option>
                                <option value="Shariatpur">Shariatpur</option>
                                <option value="Shatkhira">Shatkhira</option>
                                <option value="Sherpur">Sherpur</option>
                                <option value="Sirajganj">Sirajganj</option>
                                <option value="Sunamganj">Sunamganj</option>
                                <option value="Sylhet">Sylhet</option>
                                <option value="Tangail">Tangail</option>
                                <option value="Thakurgaon">Thakurgaon</option>
                            </select>

                        </div>

                        <div class="mb-4">
                            <input class="form-control" type="text" name="postcode" placeholder="Postal Code"
                                value="<?php echo e($stall->postcode); ?>" required>
                        </div>

                        <div class="mb-4">
                            <input class="form-control" type="text" name="country" placeholder="Country"
                                value="<?php echo e($stall->country); ?>" required>
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="business" placeholder="Business"
                                value="<?php echo e($stall->business); ?>" required>
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="phone" placeholder="Phone Number"
                                value="<?php echo e($stall->phone); ?>" required>
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="hotline1" placeholder="Hotline1"
                                value="<?php echo e($stall->hotline1); ?>" required>
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="hotline2" placeholder="Hotline2"
                                value="<?php echo e($stall->hotline2); ?>">
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="email" name="email" placeholder="Email"
                                value="<?php echo e($stall->email); ?>" required>
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="web" placeholder="Web"
                                value="<?php echo e($stall->web); ?>">
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="fax" placeholder="Fax"
                                value="<?php echo e($stall->fax); ?>">
                        </div>
                        <div class="mb-4">
                            <input class="form-control" type="text" name="person_name" placeholder="Contact Person"
                                value="<?php echo e($stall->person_name); ?>" required>
                        </div>

                        <div class="mt-3">
                            <label>Discription</label>

                            <textarea id="textarea1" name="about" class="form-control" maxlength="225" rows="3"
                                placeholder="This Discription has a limit of 225 chars." required><?php echo e($stall->about); ?></textarea>
                        </div>



                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">Picture Upload</h4>
                    <p class="card-title-desc"> Upload 512x512 px</p>
                    <div class="col-md-6">
                        <?php if(Storage::disk('public')->exists('stall/'.$stall->img)): ?>

                        <img class="img-thumbnail" alt="200x200" style="width:300px;" src="<?php echo e(asset('/'.$stall->img)); ?>" data-holder-rendered="true">

                        <?php else: ?>

                        <img class="img-thumbnail" alt="200x200" style="width:300px;" src="<?php echo e(asset('img/'.$stall->img)); ?>" data-holder-rendered="true">

                        <?php endif; ?>
                    </div>
                    <br>
                    <div class="custom-file">
                        <input type="file" name="img" class="custom-file-input" id="customFile">
                        <label class="custom-file-label" for="customFile">Choose Image</label>
                    </div>
                    <br><br>
                    <div class="mb-4">
                        <input class="form-control" type="text" name="plan" placeholder="Plan Name"
                            value="<?php echo e($stall->plan); ?>" required>
                    </div>
                    <div class="mb-4">
                        <label class="control-label">Expare Date</label>
                        <input class="form-control" type="date" name="item_exp" placeholder="Expare Date"
                            value="<?php echo e($stall->item_exp); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="control-label">Post Limit</label>
                        <input class="form-control" type="number" name="item_limit" placeholder="50"
                            value="<?php echo e($stall->item_limit); ?>" required>
                    </div>

                    <br>

                    <?php if(!$stall->user()->find($stall->user_id)->is_seller == 1): ?>

                    <div class="custom-control custom-switch mb-2" dir="ltr">
                        <input type="checkbox" name="is_seller" class="custom-control-input" id="customSwitch1"
                            value="true"
                            <?php echo e($stall->user()->find($stall->user_id)->is_seller == true ?'checked' : ''); ?>>
                        <label class="custom-control-label" for="customSwitch1">Approve Seller</label>
                    </div>

                    <?php else: ?>

                    <div class="custom-control custom-switch mb-2" dir="ltr">
                        <input type="checkbox" name="status" class="custom-control-input" id="customSwitch2" value="1"
                            <?php echo e($stall->status == true ?'checked' : ''); ?>>
                        <label class="custom-control-label" for="customSwitch2">Active/Disable Store</label>
                    </div>

                    <?php endif; ?>

                    


                </div>
                <div class="card-body">

                    <a href="<?php echo e(route('admin.stall.index')); ?>"
                        class="btn btn-danger waves-effect waves-light">
                        Back
                    </a>
                    <button type="submit" class="btn btn-primary waves-effect waves-light">
                        Update <i class="ri-arrow-right-line align-middle ml-2"></i>
                    </button>

                </div>
            </div>
        </div>
    </div>
</form>



<!-- end main content-->
<?php $__env->startPush('js'); ?>

    <!-- Summernote js -->
    <script src="<?php echo e(asset('admin/assets/libs/summernote/summernote-bs4.min.js')); ?>"></script>

    <!-- bs custom file input plugin -->
    <script
        src="<?php echo e(asset('admin/assets/libs/bs-custom-file-input/bs-custom-file-input.min.js')); ?>">
    </script>

    <script src="<?php echo e(asset('admin/assets/js/pages/form-element.init.js')); ?>"></script>
    <!--tinymce js-->
    <script src="<?php echo e(asset('admin/assets/libs/tinymce/tinymce.min.js')); ?>"></script>

    <!-- init js -->
    <script src="<?php echo e(asset('admin/assets/js/pages/form-editor.init.js')); ?>"></script>

    



<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/admin/stall/edit.blade.php ENDPATH**/ ?>