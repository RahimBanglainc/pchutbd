<?php $__env->startSection('title','Dashboard'); ?>


<?php $__env->startSection('main'); ?>

<div id="app">

    <div name="clientForm" action="" method="post">


        <input type="hidden" name="UserID" value="23272">

        <div class="container">

            <div class="row">


                <?php echo $__env->make('storefront.components.saidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                <div class="ten columns account-head">

                    <div class="body-header body-gap">

                        <h1>My Profile</h1>
                    </div>




                    <div class="row">
                        <div class="eight columns account-profile">
                            <div><?php echo e(Auth::User()->name); ?><br>

                                Member Since : <?php echo e(Auth::User()->created_at->toFormattedDateString()); ?>

                            </div>

                            <div class="row account-style account-profile">
                                <div class="four columns">
                                    <?php if(Storage::disk('public')->exists('user/'.Auth::User()->img)): ?>

                                    <img src="<?php echo e(asset('/'.Auth::User()->img)); ?>">

                                    <?php else: ?>

                                    <img src="<?php echo e(asset('img/user.jpg')); ?>">

                                    <?php endif; ?>
                                </div>

                                <div class="eight columns">

                                    Email : <?php echo e(Auth::User()->email); ?><br>

                                    Address : <?php echo e(Auth::User()->address); ?><br>
                                    City : <?php echo e(Auth::User()->city); ?><br>
                                    Country : <?php echo e(Auth::User()->country); ?><br>
                                    Phone : <?php echo e(Auth::User()->phone); ?><br>
                                    Gender :<?php echo e(Auth::User()->gender); ?><br>
                                </div>
                            </div>
                        </div>

                        <?php if(Auth::User()->is_seller): ?>

                        <div class="four columns account-head account-profile">


                            <div><b>My Account</b></div>

                            Plan Name: <font color="olive"><?php echo e(Auth::User()->stall()->where('user_id', Auth::User()->id)->first()->plan); ?></font><br>

                            Item: <font color="olive"><?php echo e($a); ?> of <?php echo e(Auth::User()->stall()->where('user_id', Auth::User()->id)->first()->item_limit); ?>


                                <a href="#" style="margin-left: 0.2em">more&gt;&gt;</a><br>
                            </font> Free Item: <font color="olive">1</font><br>


                            Post Left: <font color="olive"><?php echo e($count); ?></font><br>


                            Plan End: <font color="olive"><?php echo e(Auth::User()->stall()->where('user_id', Auth::User()->id)->first()->item_exp); ?></font><br>

                        

                            <a href="#">Get More Limit</a>

                            <div class="s-top">
                                <!--        <a href="#/productListing/limit_info/" style="color:#257AB1;float: left">View Limit Info</a><br>-->
                                <a href="#" style="color:#257AB1;float: left">View
                                    Payement Info</a>
                            </div>

                        </div>

                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/storefront/deshboard.blade.php ENDPATH**/ ?>