<?php $__env->startSection('title','View Stall'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0">Dashboard</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">PCHUTBD</a></li>
                    <li class="breadcrumb-item active">View Stall</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->



<div class="row">


    <div class="col-lg-3">
        <div class="card">
            <div class="card-header">
                <h6><b> <a href="#"><?php echo e($stall->user()->find($stall->user_id)->first()->name); ?></a></b>
                    <span class="badge badge-primary"><?php echo e($stall->id); ?></span></h6>
            </div>
            <div class="card-body">
                <blockquote class="card-blockquote mb-0">
                    <?php if(Storage::disk('public')->exists('stall/'.$stall->img)): ?>

                    <img class="img-thumbnail" alt="200x200" style="width:500px;" src="<?php echo e(asset('/'.$stall->img)); ?>" data-holder-rendered="true">

                    <?php else: ?>

                    <img class="img-thumbnail" alt="200x200" style="width:500px;" src="<?php echo e(asset('img/picture.jpg')); ?>" data-holder-rendered="true">

                    <?php endif; ?>
                    <br>
                    <footer class="blockquote-footer font-size-12">
                        Item/Post Limit: <cite title="Source Title">
                            <span class="badge badge-primary"><?php echo e($stall->item_limit); ?></span></cite>
                    </footer>
                    <footer class="blockquote-footer font-size-12">
                        Plan End: <cite title="Source Title"><span class="badge badge-warning"><?php echo e($stall->item_exp); ?></span>-<?php echo e($stall->plan); ?></cite>
                    </footer>
                    <br>
                    <a href="<?php echo e(route('admin.stall.index')); ?>" class="btn btn-danger waves-effect waves-light">Back</a>
                    <a href="<?php echo e(route('admin.stall.edit', $stall->id)); ?>" class="btn btn-primary waves-effect waves-light">Edit</a>
                </blockquote>
            </div>
        </div>
    </div>




    <div class="col-lg-9">
        <div class="card">
            <div class="card-header">
                <h3><?php echo e($stall->title); ?></h3>
            <small>Joined on <?php echo e($stall->created_at->toFormattedDateString()); ?>

                <?php if($stall->user()->find($stall->user_id)->is_seller == true): ?>


                    <span class="badge badge-pill badge-soft-success">Approve</span>

                <?php else: ?>

                    <span class="badge badge-pill badge-soft-danger">Not Approve</span>

                <?php endif; ?>
            </small>
            <small>
                <?php if($stall->status == true): ?>


                    <span class="badge badge-pill badge-soft-success">Active</span>

                <?php else: ?>

                    <span class="badge badge-pill badge-soft-danger">Disable</span>

                <?php endif; ?>
            </small>
            </div>
            <div class="card-body" style="color: white; font-size: 17px;">
                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall Name:</b>
                    </div>
                    <div class="col-lg-9">
                    <small><?php echo e($stall->name); ?></small>
                    </div>
                </div>

                    <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall Address:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->address); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall Area:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->area); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall City:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->city); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Postal Code:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->postcode); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Country:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->country); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Business:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->business); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall type:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->type); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall Phone:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->phone); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Hotlines:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->hotline1); ?></small>,
                        <small><?php echo e($stall->hotline2); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall Email:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->email); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall Web:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->web); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall Fax:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->fax); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Contact Person:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->person_name); ?></small>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-3">
                        <b>Stall Description:</b>
                    </div>
                    <div class="col-lg-9">
                        <small><?php echo e($stall->about); ?></small>
                    </div>
                </div>



            </div>
            <div class="card-footer text-muted">
                Updated on <?php echo e($stall->updated_at->diffForHumans()); ?>

            </div>
        </div>
    </div>



</div>
<!-- end row -->
<!-- end main content-->
<?php $__env->startPush('css'); ?>



<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pchutbd\resources\views/admin/stall/show.blade.php ENDPATH**/ ?>