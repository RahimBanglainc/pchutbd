export default {
    components: { },

    mixins: [

    ],

    props: [''],

    data() {
        return {

        };
    },

    computed: {

    },

    created() {

    },

    methods: {

    },
};
