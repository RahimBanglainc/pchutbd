export default {
    components: { },

    mixins: [

    ],

    props: ['devinfo'],

    data() {
        return {
            devinfo: 'Develop with <i class="mdi mdi-heart text-danger"></i> by RBsoft Technologies.',

        };
    },

    computed: {

    },

    created() {

        consolel.log('access successfully')

    },

    methods: {

    },
};
